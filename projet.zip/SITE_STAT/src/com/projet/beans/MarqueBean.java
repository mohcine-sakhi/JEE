package com.projet.beans;
import java.io.Serializable;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

@ManagedBean
@RequestScoped
public class MarqueBean implements Serializable{
	

				    private static final long serialVersionUID = 1L;

				    private String nom;
				    private String descrip;
				    private String prix;
					public String getNom() {
						return nom;
					}
					public void setNom(String nom) {
						this.nom = nom;
					}
					public String getDescrip() {
						return descrip;
					}
					public void setDescrip(String descrip) {
						this.descrip = descrip;
					}
					public String getPrix() {
						return prix;
					}
					public void setPrix(String prix) {
						this.prix = prix;
					}

				    

			}






