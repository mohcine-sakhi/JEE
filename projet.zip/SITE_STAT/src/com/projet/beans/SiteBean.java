package com.projet.beans;

import java.io.Serializable;
import java.util.ArrayList;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

@ManagedBean
@RequestScoped
public class SiteBean implements Serializable {

	

	    private static final long serialVersionUID = 1L;

	    private String nom;
	    private String descrip;
	    private String contact;
	    private ArrayList<ProductBean> products;

	    public String getDescrip() {
			return descrip;
		}

		public void setDescrip(String descrip) {
			this.descrip = descrip;
		}

		public String getContact() {
			return contact;
		}

		public void setContact(String contact) {
			this.contact = contact;
		}

		public String getNom() {
	        return nom;
	    }

	    public void setNom( String nom ) {
	        this.nom = nom;
	    }

		public ArrayList<ProductBean> getProducts() {
			return products;
		}

		public void setProducts(ArrayList<ProductBean> products) {
			this.products = products;
		}
	}


